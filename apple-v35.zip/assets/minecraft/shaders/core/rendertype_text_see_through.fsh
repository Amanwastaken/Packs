#version 150


#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in vec4  vertexColor;
in vec2  texCoord0;

in vec2       glyphUV;
flat in int   effectId;
flat in float shadowFlag;

out vec4 fragColor;

#define NO_FOG
#moj_import <minecraft:text_effects_speed.glsl>
#moj_import <minecraft:color_effects_frag.glsl>

void main() {
    runText();
}
