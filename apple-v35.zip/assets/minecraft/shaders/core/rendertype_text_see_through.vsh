#version 150


#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out vec2       glyphUV;
flat out int   effectId;
flat out float shadowFlag;

#define NO_LIGHTMAP
#moj_import <minecraft:color_effects.glsl>

void main() {
    texCoord0 = UV0;
    applyTextEffects();
}
