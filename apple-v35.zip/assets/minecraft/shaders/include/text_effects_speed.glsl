#define COLOR_SPEED 1.0
