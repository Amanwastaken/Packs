#version 150

#define TAU 6.28318

float gGvY;
float gHpos;

vec3 hue(float t) {
    return clamp(0.55 + 0.45 * cos(TAU * t + vec3(0.0, 2.0944, 4.1888)), 0.0, 1.0);
}
float sheenBand(float speed, float width, float tilt) {
    float sweep = fract((GameTime * float(COLOR_SPEED)) * speed);
    float pos   = fract(gl_FragCoord.x / ScreenSize.x + gl_FragCoord.y / ScreenSize.x * tilt);
    float d     = min(abs(pos - sweep), 1.0 - abs(pos - sweep));
    return smoothstep(width, 0.0, d);
}

// gradients - axisMode: 0 horizontal, 1 vertical, 2 diagonal
vec3 gradFX(vec3 a, vec3 b, vec3 c, int stops, int axisMode, float spatial, float spd) {
    float axis = (axisMode == 0) ? gHpos : (axisMode == 1) ? gGvY : (gHpos * 0.6 + gGvY * 0.9);
    float t = 0.5 + 0.5 * sin(axis * spatial - (GameTime * float(COLOR_SPEED)) * spd);
    if (stops < 3) return mix(a, b, t);
    return (t < 0.5) ? mix(a, b, t * 2.0) : mix(b, c, (t - 0.5) * 2.0);
}
vec3 grad4FX(vec3 a, vec3 b, vec3 c, vec3 d, int axisMode, float spatial, float spd) {
    float axis = (axisMode == 0) ? gHpos : (axisMode == 1) ? gGvY : (gHpos * 0.6 + gGvY * 0.9);
    float t = 0.5 + 0.5 * sin(axis * spatial - (GameTime * float(COLOR_SPEED)) * spd);
    if      (t < 0.333) return mix(a, b, t * 3.0);
    else if (t < 0.667) return mix(b, c, (t - 0.333) * 3.0);
    else                return mix(c, d, (t - 0.667) * 3.0);
}

// signature flows (vertical)
vec3 fireFX(vec3 hot, vec3 mid, vec3 cool, float spd) {
    float f = fract(gGvY + (GameTime * float(COLOR_SPEED)) * spd);
    return (f < 0.5) ? mix(hot, mid, f * 2.0) : mix(mid, cool, (f - 0.5) * 2.0);
}
vec3 waterFX(vec3 lo, vec3 hi, float cycles, float spd) {
    return mix(lo, hi, 0.5 + 0.5 * sin((gGvY * cycles - (GameTime * float(COLOR_SPEED)) * spd) * TAU));
}
vec3 auroraFX(vec3 a, vec3 b, vec3 c, float spd) {
    float t = fract(gGvY * 0.5 + (GameTime * float(COLOR_SPEED)) * spd);
    return (t < 0.5) ? mix(a, b, t * 2.0) : mix(b, c, (t - 0.5) * 2.0);
}
vec3 frostFX(vec3 lo, vec3 hi, float spd) {
    float line = 0.5 + 0.5 * sin((GameTime * float(COLOR_SPEED)) * spd);
    return mix(lo, hi, smoothstep(line + 0.12, line - 0.12, gGvY));
}
vec3 prismFX(float spd, float sat) {
    return mix(vec3(1.0), hue(fract(gGvY + (GameTime * float(COLOR_SPEED)) * spd)), sat);
}
vec3 rainbowFX(float spatial, float spd) {
    return hue(fract(gHpos * spatial + (GameTime * float(COLOR_SPEED)) * spd));
}

// sheen / metallic
vec3 chromeFX(vec3 tint, float spd) {
    float sweep = 1.0 - fract((GameTime * float(COLOR_SPEED)) * spd);
    float spec  = smoothstep(0.14, 0.0, abs(gGvY - sweep));
    return clamp(tint * mix(0.45, 1.00, gGvY) + spec * vec3(1.0), 0.0, 1.0);
}
vec3 diamondFX(vec3 base, float spd, float w) {
    return clamp(base + sheenBand(spd, w, 0.20) * 1.40, 0.0, 1.0);
}

// heartbeat
float heartBeat(float spd) {
    float t = fract((GameTime * float(COLOR_SPEED)) * spd), d1 = t - 0.10, d2 = t - 0.28;
    return 0.70 + 0.60 * (exp(-40.0 * d1 * d1) + 0.7 * exp(-40.0 * d2 * d2));
}
vec3 heartFX(vec3 base, float spd) { return clamp(base * heartBeat(spd), 0.0, 1.0); }

void emit(vec4 color) {
    if (color.a < 0.1) discard;
#ifdef NO_FOG
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance,
                          FogEnvironmentalStart, FogEnvironmentalEnd,
                          FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}

vec3 unpackRgb10(uint v) {
    return vec3(float((v >> 20u) & 1023u), float((v >> 10u) & 1023u), float(v & 1023u)) / 1023.0;
}

const uvec4 FX_COL[150] = uvec4[](
    uvec4(1073130259u,1073741823u,0u,0u),
    uvec4(252315647u,1073741823u,0u,0u),
    uvec4(387911418u,1073741823u,0u,0u),
    uvec4(1073540457u,1073704771u,0u,0u),
    uvec4(1072930896u,1073491241u,0u,0u),
    uvec4(1073259729u,1072931434u,0u,0u),
    uvec4(1072881961u,1072882530u,0u,0u),
    uvec4(1073130274u,312347647u,0u,0u),
    uvec4(589546435u,1073130274u,0u,0u),
    uvec4(109873874u,177646591u,0u,0u),
    uvec4(945913920u,1073450128u,0u,0u),
    uvec4(589604803u,1072998274u,0u,0u),
    uvec4(252578354u,379523011u,0u,0u),
    uvec4(1072931538u,1073326289u,0u,0u),
    uvec4(219711487u,513575935u,1073741823u,0u),
    uvec4(311797759u,648325059u,1073130274u,0u),
    uvec4(1072930937u,1073259664u,1073646953u,0u),
    uvec4(178031314u,379523071u,1073741823u,0u),
    uvec4(589604706u,1073130194u,1073514857u,0u),
    uvec4(177948752u,649067729u,977272643u,0u),
    uvec4(312314217u,977177961u,1073130194u,0u),
    uvec4(1073260403u,841615359u,513575935u,0u),
    uvec4(920575u,757072895u,0u,0u),
    uvec4(1073063553u,1073556777u,379522850u,0u),
    uvec4(84934250u,42272767u,0u,0u),
    uvec4(649007103u,311864319u,0u,0u),
    uvec4(1073741823u,589957119u,243443490u,0u),
    uvec4(1072997802u,2147298601u,312413825u,379103231u),
    uvec4(513411071u,942443519u,0u,0u),
    uvec4(243706658u,513575778u,977272771u,0u),
    uvec4(841591807u,649006978u,0u,0u),
    uvec4(1073416833u,1073580802u,1073696675u,0u),
    uvec4(1073063209u,1073515137u,0u,0u),
    uvec4(1073326160u,1073613289u,0u,0u),
    uvec4(1073556560u,1073704642u,0u,0u),
    uvec4(1073416336u,1073129712u,0u,0u),
    uvec4(1073194105u,1073580458u,0u,0u),
    uvec4(1073326569u,1073613635u,0u,0u),
    uvec4(1072997865u,1073416833u,0u,0u),
    uvec4(945914113u,1073130025u,0u,0u),
    uvec4(740376816u,1073063401u,0u,0u),
    uvec4(1072882530u,1073350595u,0u,0u),
    uvec4(512927338u,908504003u,0u,0u),
    uvec4(757639107u,977112063u,0u,0u),
    uvec4(648587203u,876383231u,0u,0u),
    uvec4(447195075u,741084159u,0u,0u),
    uvec4(243443490u,513190851u,0u,0u),
    uvec4(109290370u,379103231u,0u,0u),
    uvec4(84380671u,590121983u,0u,0u),
    uvec4(177866626u,673057791u,0u,0u),
    uvec4(84519530u,379456354u,0u,0u),
    uvec4(84708050u,673124259u,0u,0u),
    uvec4(84806595u,842006527u,0u,0u),
    uvec4(127617450u,513740482u,0u,0u),
    uvec4(252291241u,648939881u,0u,0u),
    uvec4(177948969u,741342770u,0u,0u),
    uvec4(673056848u,977272370u,0u,0u),
    uvec4(841394345u,1073416681u,0u,0u),
    uvec4(672400488u,942187881u,0u,0u),
    uvec4(1073194410u,1073482434u,0u,0u),
    uvec4(1073063530u,1073416994u,0u,0u),
    uvec4(875659649u,1073130113u,0u,0u),
    uvec4(1073129833u,1073450410u,0u,0u),
    uvec4(1073408770u,1073647555u,0u,0u),
    uvec4(1073482025u,1073260322u,0u,0u),
    uvec4(311797225u,672877410u,0u,0u),
    uvec4(378972713u,808242050u,0u,0u),
    uvec4(243507561u,580429570u,0u,0u),
    uvec4(446775536u,841262569u,0u,0u),
    uvec4(580036010u,942058178u,0u,0u),
    uvec4(379036841u,741181866u,0u,0u),
    uvec4(580749738u,942669602u,0u,0u),
    uvec4(177646591u,589670339u,1073130274u,0u),
    uvec4(42576425u,178031490u,378973183u,0u),
    uvec4(1072997545u,1073326249u,1073613161u,0u),
    uvec4(243443490u,757376963u,1073260355u,0u),
    uvec4(177842416u,648939881u,1010826946u,0u),
    uvec4(1073260322u,1073580673u,741281666u,0u),
    uvec4(1072882530u,513124291u,178031615u,0u),
    uvec4(42444329u,178031314u,842006402u,0u),
    uvec4(1072930896u,1073491241u,0u,0u),
    uvec4(1072881961u,1073326698u,0u,0u),
    uvec4(1073540457u,1073680130u,0u,0u),
    uvec4(648325059u,942278655u,0u,0u),
    uvec4(178031490u,808390655u,0u,0u),
    uvec4(177948969u,741342770u,0u,0u),
    uvec4(84708226u,842006527u,0u,0u),
    uvec4(177646591u,672959487u,0u,0u),
    uvec4(42576425u,178031458u,876609475u,0u),
    uvec4(513058755u,876218367u,0u,0u),
    uvec4(252578433u,876609443u,0u,0u),
    uvec4(1072997994u,1073482594u,0u,0u),
    uvec4(1073130274u,1073549234u,0u,0u),
    uvec4(648939881u,977272578u,0u,0u),
    uvec4(178031490u,841990143u,0u,0u),
    uvec4(1073540457u,1073680130u,0u,0u),
    uvec4(1073556777u,3220546681u,740294848u,0u),
    uvec4(939487231u,2384161791u,42116898u,0u),
    uvec4(1006632642u,2669545769u,84296704u,0u),
    uvec4(1073549311u,2955257795u,243311106u,0u),
    uvec4(1073741823u,2737703935u,177646370u,0u),
    uvec4(1073680066u,3220974889u,775312505u,0u),
    uvec4(1073613746u,3220613907u,672235905u,0u),
    uvec4(1006632498u,2796423553u,177710160u,0u),
    uvec4(1073432816u,3220365392u,269484032u,0u),
    uvec4(1073556777u,3220546560u,134217728u,0u),
    uvec4(521964543u,2274732031u,16793728u,0u),
    uvec4(766508393u,2399963216u,16859136u,0u),
    uvec4(42189602u,3811381247u,0u,0u),
    uvec4(67503489u,3609070403u,0u,0u),
    uvec4(512835584u,4294658288u,0u,0u),
    uvec4(84255784u,3894410561u,0u,0u),
    uvec4(512819488u,4294552387u,0u,0u),
    uvec4(109093104u,3873818623u,0u,0u),
    uvec4(243639785u,4130262015u,0u,0u),
    uvec4(1209007730u,135039999u,652593151u,0u),
    uvec4(2146872083u,672574463u,312249343u,0u),
    uvec4(2147233065u,1073129712u,807774147u,0u),
    uvec4(1461586642u,252480354u,177646370u,0u),
    uvec4(2146805418u,1073556777u,312249343u,0u),
    uvec4(1520872387u,757442499u,1073130259u,0u),
    uvec4(134259202u,1586627330u,1072997890u,311864319u),
    uvec4(42049897u,1325573738u,757442499u,1073326915u),
    uvec4(67174592u,1385407082u,841395139u,1073613441u),
    uvec4(1073741824u,2147483648u,0u,0u),
    uvec4(1073741824u,2147483648u,0u,0u),
    uvec4(1073741824u,2147483648u,0u,0u),
    uvec4(1073741824u,2147483648u,0u,0u),
    uvec4(1073741824u,3221225472u,0u,0u),
    uvec4(1073741824u,3221225472u,0u,0u),
    uvec4(1073741824u,3221225472u,0u,0u),
    uvec4(1326057471u,2034184191u,0u,0u),
    uvec4(1251388194u,1915654143u,0u,0u),
    uvec4(1461488482u,2147483647u,0u,0u),
    uvec4(2737507327u,0u,0u,0u),
    uvec4(2820344578u,0u,0u,0u),
    uvec4(3221040425u,0u,0u,0u),
    uvec4(2955709282u,0u,0u,0u),
    uvec4(2669546242u,0u,0u,0u),
    uvec4(2989362175u,1073741824u,0u,0u),
    uvec4(3220481450u,1073741824u,0u,0u),
    uvec4(2400029098u,1073741824u,0u,0u),
    uvec4(2399643647u,1073741824u,0u,0u),
    uvec4(3220974889u,1073741824u,0u,0u),
    uvec4(2904992707u,1073741824u,0u,0u),
    uvec4(3220350225u,2147483648u,0u,0u),
    uvec4(3220613907u,2147483648u,0u,0u),
    uvec4(3220974889u,2147483648u,0u,0u),
    uvec4(2400029098u,2147483648u,0u,0u),
    uvec4(2399643647u,2147483648u,0u,0u));
const vec4 FX_PRM[150] = vec4[](
    vec4(2.0,0.0,7.0,5075.0),
    vec4(2.0,0.0,7.0,5075.0),
    vec4(2.0,0.0,7.0,5075.0),
    vec4(2.0,0.0,7.0,4550.0),
    vec4(2.0,0.0,8.0,5250.0),
    vec4(2.0,2.0,8.0,6250.0),
    vec4(2.0,0.0,9.0,8000.0),
    vec4(2.0,2.0,9.0,7000.0),
    vec4(2.0,0.0,8.0,6750.0),
    vec4(2.0,0.0,7.0,6000.0),
    vec4(2.0,1.0,8.0,7500.0),
    vec4(2.0,0.0,8.0,6750.0),
    vec4(2.0,0.0,7.0,6000.0),
    vec4(2.0,2.0,9.0,7250.0),
    vec4(3.0,1.0,7.0,5750.0),
    vec4(3.0,1.0,7.0,6000.0),
    vec4(3.0,1.0,7.0,-6250.0),
    vec4(3.0,0.0,7.0,5750.0),
    vec4(3.0,0.0,7.0,6000.0),
    vec4(3.0,1.0,7.0,6500.0),
    vec4(3.0,2.0,8.0,6250.0),
    vec4(3.0,2.0,8.0,6000.0),
    vec4(2.0,0.0,20.0,11000.0),
    vec4(3.0,0.0,22.0,10000.0),
    vec4(2.0,0.0,22.0,12000.0),
    vec4(2.0,1.0,14.0,9500.0),
    vec4(3.0,0.0,24.0,13000.0),
    vec4(0.0,22.0,10000.0,0.0),
    vec4(2.0,0.0,5.0,3500.0),
    vec4(3.0,0.0,5.0,3100.0),
    vec4(2.0,1.0,5.0,3200.0),
    vec4(3.0,0.0,5.0,2800.0),
    vec4(2.0,0.0,8.0,6000.0),
    vec4(2.0,0.0,8.0,6000.0),
    vec4(2.0,0.0,8.0,5750.0),
    vec4(2.0,2.0,9.0,6500.0),
    vec4(2.0,1.0,8.0,6250.0),
    vec4(2.0,0.0,7.0,5250.0),
    vec4(2.0,2.0,8.0,6000.0),
    vec4(2.0,0.0,9.0,4900.0),
    vec4(2.0,1.0,8.0,6500.0),
    vec4(2.0,0.0,9.0,7250.0),
    vec4(2.0,0.0,8.0,6250.0),
    vec4(2.0,0.0,7.0,5000.0),
    vec4(2.0,1.0,7.0,5000.0),
    vec4(2.0,0.0,7.0,5250.0),
    vec4(2.0,2.0,8.0,6000.0),
    vec4(2.0,0.0,8.0,6250.0),
    vec4(2.0,0.0,7.0,5750.0),
    vec4(2.0,1.0,7.0,5500.0),
    vec4(2.0,0.0,8.0,6000.0),
    vec4(2.0,0.0,8.0,6000.0),
    vec4(2.0,0.0,9.0,6750.0),
    vec4(2.0,1.0,8.0,6000.0),
    vec4(2.0,0.0,8.0,6000.0),
    vec4(2.0,2.0,8.0,6250.0),
    vec4(2.0,0.0,9.0,6750.0),
    vec4(2.0,1.0,8.0,6000.0),
    vec4(2.0,0.0,8.0,4375.0),
    vec4(2.0,0.0,7.0,5250.0),
    vec4(2.0,2.0,8.0,6000.0),
    vec4(2.0,0.0,9.0,4900.0),
    vec4(2.0,2.0,8.0,6250.0),
    vec4(2.0,0.0,6.0,4750.0),
    vec4(2.0,2.0,8.0,6000.0),
    vec4(2.0,0.0,7.0,5000.0),
    vec4(2.0,1.0,7.0,5000.0),
    vec4(2.0,0.0,8.0,5750.0),
    vec4(2.0,1.0,8.0,6250.0),
    vec4(2.0,0.0,8.0,4375.0),
    vec4(2.0,0.0,8.0,4200.0),
    vec4(2.0,0.0,7.0,3675.0),
    vec4(3.0,0.0,7.0,6000.0),
    vec4(3.0,2.0,8.0,6250.0),
    vec4(3.0,1.0,7.0,6250.0),
    vec4(3.0,1.0,7.0,6000.0),
    vec4(3.0,0.0,7.0,5750.0),
    vec4(3.0,2.0,8.0,6000.0),
    vec4(3.0,0.0,9.0,7500.0),
    vec4(3.0,1.0,7.0,5750.0),
    vec4(2.0,0.0,8.0,7500.0),
    vec4(2.0,0.0,8.0,7250.0),
    vec4(2.0,0.0,8.0,6500.0),
    vec4(2.0,0.0,8.0,6750.0),
    vec4(2.0,0.0,8.0,6500.0),
    vec4(2.0,0.0,8.0,6500.0),
    vec4(2.0,0.0,7.0,5750.0),
    vec4(2.0,0.0,7.0,5750.0),
    vec4(3.0,0.0,7.0,5500.0),
    vec4(2.0,0.0,7.0,6000.0),
    vec4(2.0,1.0,7.0,5500.0),
    vec4(2.0,0.0,7.0,6000.0),
    vec4(2.0,0.0,8.0,6250.0),
    vec4(2.0,0.0,8.0,6250.0),
    vec4(2.0,0.0,8.0,6250.0),
    vec4(2.0,0.0,8.0,6250.0),
    vec4(1500.0,0.0,0.0,0.0),
    vec4(1500.0,0.0,0.0,0.0),
    vec4(1450.0,0.0,0.0,0.0),
    vec4(1500.0,0.0,0.0,0.0),
    vec4(1400.0,0.0,0.0,0.0),
    vec4(1450.0,0.0,0.0,0.0),
    vec4(1500.0,0.0,0.0,0.0),
    vec4(1500.0,0.0,0.0,0.0),
    vec4(1650.0,0.0,0.0,0.0),
    vec4(1600.0,0.0,0.0,0.0),
    vec4(1650.0,0.0,0.0,0.0),
    vec4(1650.0,0.0,0.0,0.0),
    vec4(0.75,450.0,0.0,0.0),
    vec4(0.75,430.0,0.0,0.0),
    vec4(0.8,470.0,0.0,0.0),
    vec4(0.8,470.0,0.0,0.0),
    vec4(0.75,440.0,0.0,0.0),
    vec4(0.8,460.0,0.0,0.0),
    vec4(0.7,400.0,0.0,0.0),
    vec4(320.0,0.0,0.0,0.0),
    vec4(320.0,0.0,0.0,0.0),
    vec4(300.0,0.0,0.0,0.0),
    vec4(320.0,0.0,0.0,0.0),
    vec4(340.0,0.0,0.0,0.0),
    vec4(320.0,0.0,0.0,0.0),
    vec4(0.0,6.0,1150.0,0.0),
    vec4(0.0,6.0,1430.0,0.0),
    vec4(1.0,6.0,1900.0,0.0),
    vec4(400.0,0.85,0.0,0.0),
    vec4(300.0,0.45,0.0,0.0),
    vec4(600.0,1.0,0.0,0.0),
    vec4(300.0,0.3,0.0,0.0),
    vec4(3.0,260.0,0.0,0.0),
    vec4(6.0,520.0,0.0,0.0),
    vec4(1.5,156.0,0.0,0.0),
    vec4(900.0,0.0,0.0,0.0),
    vec4(820.0,0.0,0.0,0.0),
    vec4(860.0,0.0,0.0,0.0),
    vec4(500.0,0.0,0.0,0.0),
    vec4(480.0,0.0,0.0,0.0),
    vec4(520.0,0.0,0.0,0.0),
    vec4(500.0,0.0,0.0,0.0),
    vec4(500.0,0.0,0.0,0.0),
    vec4(700.0,0.07,0.0,0.0),
    vec4(680.0,0.08,0.0,0.0),
    vec4(680.0,0.08,0.0,0.0),
    vec4(680.0,0.08,0.0,0.0),
    vec4(680.0,0.08,0.0,0.0),
    vec4(680.0,0.08,0.0,0.0),
    vec4(1400.0,0.0,0.0,0.0),
    vec4(1400.0,0.0,0.0,0.0),
    vec4(1300.0,0.0,0.0,0.0),
    vec4(1350.0,0.0,0.0,0.0),
    vec4(1350.0,0.0,0.0,0.0));

void runText() {
    vec4 atlas = texture(Sampler0, texCoord0);
    if (effectId == 0) {
        emit(atlas * vertexColor * ColorModulator);
        return;
    }

    vec2  dUx = vec2(dFdx(glyphUV.x), dFdy(glyphUV.x));
    vec2  dUy = vec2(dFdx(glyphUV.y), dFdy(glyphUV.y));
    vec2  dTy = vec2(dFdx(texCoord0.y), dFdy(texCoord0.y));
    float det = dUx.x * dUy.y - dUx.y * dUy.x;
    if (abs(det) < 1e-7) {
        gGvY = glyphUV.y;
    } else {
        float dTdUx = ( dUy.y * dTy.x - dUy.x * dTy.y) / det;
        float dTdUy = (-dUx.y * dTy.x + dUx.x * dTy.y) / det;
        gGvY = (abs(dTdUy) >= abs(dTdUx))
             ? (dTdUy > 0.0 ? 1.0 - glyphUV.y : glyphUV.y)
             : (dTdUx > 0.0 ? 1.0 - glyphUV.x : glyphUV.x);
    }
    gHpos = gl_FragCoord.x / ScreenSize.x;

    vec3 col = vec3(1.0);
        if (effectId >= 1 && effectId <= 150) {
            uvec4 cw = FX_COL[effectId - 1];
            vec4  pr = FX_PRM[effectId - 1];
            vec3  A = unpackRgb10(cw.x), B = unpackRgb10(cw.y), C = unpackRgb10(cw.z), D = unpackRgb10(cw.w);
            switch (int(((cw.x >> 30u) << 2u) | (cw.y >> 30u))) {
                case 0:  col = gradFX(A, B, C, int(pr.x), int(pr.y), pr.z, pr.w); break;
                case 1:  col = grad4FX(A, B, C, D, int(pr.x), pr.y, pr.z); break;
                case 2:  col = fireFX(A, B, C, pr.x); break;
                case 3:  col = waterFX(A, B, pr.x, pr.y); break;
                case 4:  col = auroraFX(A, B, C, pr.x); break;
                case 5:  col = frostFX(A, B, pr.x); break;
                case 6:  col = prismFX(pr.x, pr.y); break;
                case 7:  col = rainbowFX(pr.x, pr.y); break;
                case 8:  col = chromeFX(A, pr.x); break;
                case 9:  col = diamondFX(A, pr.x, pr.y); break;
                default: col = heartFX(A, pr.x); break;
            }
        } else {
            col = vec3(1.0);
        }

    if (shadowFlag > 0.5) col *= 0.25;
    emit(vec4(col, atlas.a * vertexColor.a) * ColorModulator);
}
