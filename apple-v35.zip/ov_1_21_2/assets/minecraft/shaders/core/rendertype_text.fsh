#version 150


#moj_import <minecraft:fog.glsl>

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float GameTime;
uniform vec2 ScreenSize;

in float vertexDistance;
in vec4  vertexColor;
in vec2  texCoord0;

in vec2       glyphUV;
flat in int   effectId;
flat in float shadowFlag;

out vec4 fragColor;

#moj_import <minecraft:text_effects_speed.glsl>
#moj_import <minecraft:color_effects_frag.glsl>

void main() {
    runText();
}
