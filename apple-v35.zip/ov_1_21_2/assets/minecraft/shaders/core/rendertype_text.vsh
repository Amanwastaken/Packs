#version 150


#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;
uniform float GameTime;
uniform vec2 ScreenSize;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

out vec2       glyphUV;
flat out int   effectId;
flat out float shadowFlag;

#moj_import <minecraft:color_effects.glsl>

void main() {
    texCoord0 = UV0;
    applyTextEffects();
}
