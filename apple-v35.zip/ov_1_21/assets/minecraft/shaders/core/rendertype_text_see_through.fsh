#version 150


uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float GameTime;
uniform vec2 ScreenSize;

in vec4  vertexColor;
in vec2  texCoord0;

in vec2       glyphUV;
flat in int   effectId;
flat in float shadowFlag;

out vec4 fragColor;

#define NO_FOG
#moj_import <text_effects_speed.glsl>
#moj_import <color_effects_frag.glsl>

void main() {
    runText();
}
