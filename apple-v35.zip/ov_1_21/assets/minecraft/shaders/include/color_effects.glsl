#version 150

#define SHAKE_AMP   0.65
#define SHAKE_SPD   58000.0
#define WAVE_AMP    1.55
#define WAVE_SPD    5000.0
#define WAVE_FREQ   0.12
#define ITER_SPD    1100.0
#define ITER_STEP   0.020
#define ITER_AMP    2.0

float wob3(float t) {
    return sin(t) * 0.6 + sin(t * 2.3 + 1.7) * 0.3 + sin(t * 4.1 + 3.1) * 0.1;
}

int   gEffect;
float gShadow;

void tryKey(ivec3 ccol, ivec3 k, int id) {
    if (gEffect != 0) return;
    if      (all(equal(ccol, k)))     { gEffect = id; gShadow = 0.0; }
    else if (all(equal(ccol, k / 4))) { gEffect = id; gShadow = 1.0; }
}

int motionOf(int id) {
    if (id == 81) return 1;
    if (id == 82) return 1;
    if (id == 83) return 1;
    if (id == 84) return 1;
    if (id == 85) return 1;
    if (id == 86) return 1;
    if (id == 87) return 2;
    if (id == 88) return 2;
    if (id == 89) return 2;
    if (id == 90) return 2;
    if (id == 91) return 2;
    if (id == 92) return 2;
    if (id == 93) return 3;
    if (id == 94) return 3;
    if (id == 95) return 3;
    if (id == 96) return 3;
    return 0;
}

const int FX_KEY_COUNT = 150;
const uint FX_KEYS[150] = uint[](31259772u,49057004u,65850540u,82619612u,92044492u,115121372u,132951228u,150785164u,162315404u,177011852u,193772700u,214756588u,227314844u,248298748u,264015036u,276597884u,296516748u,315423948u,326945964u,350002300u,365735132u,385678508u,397200508u,410819804u,429718716u,444398716u,469535900u,479001852u,502041756u,518831324u,532462812u,545053948u,566025372u,579648684u,596429964u,619502716u,636267676u,648858764u,670878908u,680316028u,703376508u,719121548u,730659996u,753728732u,766299388u,785173676u,802987244u,821877980u,837602444u,851242172u,864849020u,885816460u,901565660u,920419580u,935099628u,953998508u,967621852u,986508540u,1006402684u,1017941244u,1038908572u,1052560524u,1071434956u,1082952844u,1104968860u,1118629068u,1136442524u,1151114460u,1170005212u,1188875420u,1202494604u,1223462076u,1236061388u,1253899516u,1274854604u,1288490204u,1304210604u,1316801724u,1335659660u,1354554492u,1371335932u,1387048108u,1408015532u,1422695660u,1438448780u,1452067996u,1468849356u,1484586156u,1508670716u,1520237772u,1534905548u,1554836668u,1573715132u,1591524540u,1609338060u,1619844268u,1641872556u,1657593004u,1675402492u,1694289148u,1703722204u,1721564332u,1737276556u,1756159164u,1769790700u,1793883308u,1806470348u,1822215404u,1842146444u,1861024924u,1875672284u,1891409020u,1911340284u,1922862284u,1945935020u,1960610956u,1975311564u,1994169548u,2005699756u,2022472892u,2040323324u,2062322812u,2074901628u,2090650796u,2112679036u,2130484412u,2138881148u,2159844492u,2177686668u,2195492076u,2212293884u,2226977964u,2245835996u,2263649452u,2276228316u,2290924748u,2315058380u,2323438748u,2348600556u,2359082172u,2374806716u,2397891820u,2407328956u,2427235580u,2445069436u,2459741388u,2480700620u,2494336140u,2507992220u,2526866588u);

void applyTextEffects() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexDistance = fog_distance(Position, FogShape);

    int corner = int(mod(float(gl_VertexID), 4.0));
    vec2 guv;
    if      (corner == 0) guv = vec2(0.0, 0.0);
    else if (corner == 1) guv = vec2(0.0, 1.0);
    else if (corner == 2) guv = vec2(1.0, 1.0);
    else                  guv = vec2(1.0, 0.0);
    glyphUV = guv;

    ivec3 key = ivec3(Color.xyz * 255.0 + 0.5);
    gEffect = 0; gShadow = 0.0;
    int keyCount = FX_KEY_COUNT + int(min(GameTime, 0.0));
    for (int i = 0; i < keyCount; i++) {
        uint  e = FX_KEYS[i];
        ivec3 k = ivec3(int((e >> 16u) & 255u), int((e >> 8u) & 255u), int(e & 255u));
        if (all(equal(key, k)))     { gEffect = int(e >> 24u); gShadow = 0.0; break; }
        if (all(equal(key, k / 4))) { gEffect = int(e >> 24u); gShadow = 1.0; break; }
    }
    effectId   = gEffect;
    shadowFlag = gShadow;

    if (gEffect == 0) {
#ifdef NO_LIGHTMAP
        vertexColor = Color;
#else
        vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
#endif
        return;
    }

    int   m    = motionOf(gEffect);
    vec2  px   = vec2(0.0);
    float seed = Position.x;

    if (m == 1) {                                      // shake
        px.x += wob3(GameTime * SHAKE_SPD        + seed * 0.7)       * SHAKE_AMP;
        px.y += wob3(GameTime * SHAKE_SPD * 1.17 + seed * 0.7 + 9.3) * SHAKE_AMP;
    }
    else if (m == 2) {                                 // wave
        px.y += sin(GameTime * WAVE_SPD + seed * WAVE_FREQ) * WAVE_AMP;
    }
    else if (m == 3) {                                 // hop
        float ph = fract(GameTime * ITER_SPD - seed * ITER_STEP);
        px.y += max(0.0, 1.0 - abs(ph - 0.12) / 0.12) * ITER_AMP;
    }

    gl_Position.xy += px / ScreenSize * (2.0 * gl_Position.w);
    vertexColor = vec4(1.0, 1.0, 1.0, Color.a);
}
