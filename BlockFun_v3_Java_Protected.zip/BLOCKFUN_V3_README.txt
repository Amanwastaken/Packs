BlockFun Java v3

Fixes:
- Corrected modern 1.21+ range_dispatch ordering across the pack.
- Added complete item-atlas coverage for custom item textures.
- Added 300 CustomFish COD models/textures/CMDs from the supplied fish pack.
- Added 5 PAPER power icons (CMD 95031-95035).
- Preserved Ocean + DragonSoul content and existing BlockFun models.
